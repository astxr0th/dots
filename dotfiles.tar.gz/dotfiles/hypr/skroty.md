# ⌨️ MOJE BINDY
---
* **SUPER + T** -> Terminal
* **SUPER + W** -> Przeglądarka
* **SUPER + Q** -> Zamknij okno
* **SUPER + /** -> Ta pomoc
