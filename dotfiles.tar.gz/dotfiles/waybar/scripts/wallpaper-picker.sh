#!/bin/bash
# ──────────────────────────────────────────────────────
#  wallpaper-picker.sh
#  Otwiera rofi z podglądem miniatur, ustawia tapetę
#  i dopasowuje kolory systemu do wszystkich aplikacji.
# ──────────────────────────────────────────────────────

WALLPAPER_DIR="${WALLPAPER_DIR:-$HOME/.config/wallpapers}"

# ── 1. Zbierz listę obrazów ─────────────────────────
mapfile -t WALLPAPERS < <(
    find "$WALLPAPER_DIR" -type f \
        \( -iname "*.jpg" -o -iname "*.jpeg" \
           -o -iname "*.png" -o -iname "*.webp" \
           -o -iname "*.gif" \) \
    | sort
)

if [ ${#WALLPAPERS[@]} -eq 0 ]; then
    notify-send -i dialog-error "Tapety" "Brak obrazów w katalogu:\n$WALLPAPER_DIR"
    exit 1
fi

# ── 2. Wybór tapety ─────────────────────────────────
if [ "$1" = "--random" ]; then
    WALLPAPER_PATH="${WALLPAPERS[RANDOM % ${#WALLPAPERS[@]}]}"
    SELECTED=$(basename "$WALLPAPER_PATH")
else
    SELECTED=$(
        for img in "${WALLPAPERS[@]}"; do
            printf '%s\x00icon\x1f%s\n' "$(basename "$img")" "$img"
        done | rofi -dmenu \
            -show-icons \
            -p "󰸉  Tapeta" \
            -theme "$HOME/.config/waybar/scripts/wallpaper-picker.rasi"
    )

    [ -z "$SELECTED" ] && exit 0

    WALLPAPER_PATH=$(
        for img in "${WALLPAPERS[@]}"; do
            [ "$(basename "$img")" = "$SELECTED" ] && echo "$img" && break
        done
    )
fi

[ -z "$WALLPAPER_PATH" ] && exit 1

# ── 3. Ustaw tapetę ──────────────────────────────────
swww query &>/dev/null || (swww-daemon & disown && sleep 0.5)
swww img "$WALLPAPER_PATH" \
    --transition-type grow \
    --transition-pos center \
    --transition-duration 1.2 \
    --transition-fps 60

# ── 4. Generuj kolory pywal ──────────────────────────
wal -i "$WALLPAPER_PATH" -n -q

# ── 5. Przeładuj wszystkie aplikacje ─────────────────

# Waybar
pkill -SIGUSR2 waybar 2>/dev/null

# Kitty — wszystkie otwarte okna
for pid in $(pidof kitty); do
    kill -SIGUSR1 "$pid" 2>/dev/null
done

# Zen / Firefox
command -v pywalfox &>/dev/null && pywalfox update &>/dev/null &

# Spotify
command -v spicetify &>/dev/null && spicetify apply &>/dev/null &

# Discord (Vencord/Vesktop) — generuj CSS z kolorów pywal
WAL_COLORS="$HOME/.cache/wal/colors"
if [ -f "$WAL_COLORS" ]; then
    source "$WAL_COLORS"
    DISCORD_CSS="$HOME/.cache/wal/colors-discord.css"
    cat > "$DISCORD_CSS" << CSSEOF
/**
 * @name pywal
 * @description Automatyczne kolory z pywal
 */
:root {
    --background-primary:         ${color0};
    --background-secondary:       ${color1};
    --background-tertiary:        ${color2};
    --background-accent:          ${color3};
    --channeltextarea-background:  ${color1};
    --text-normal:                ${foreground};
    --text-muted:                 ${color8};
    --interactive-normal:         ${foreground};
    --interactive-active:         ${color15};
    --brand-experiment:           ${color4};
    --mention-background:         ${color4}33;
}
CSSEOF

    # Vesktop natywny
    VESKTOP_THEMES="$HOME/.config/vesktop/themes"
    mkdir -p "$VESKTOP_THEMES"
    cp "$DISCORD_CSS" "$VESKTOP_THEMES/pywal.css"
fi

# ── 6. Powiadomienie ─────────────────────────────────
notify-send -i "$WALLPAPER_PATH" "🖼 Tapeta zmieniona" "$(basename "$WALLPAPER_PATH")"
